package com.mycompany.lab6;

import java.io.IOException;

public class Lab6 {

    public static void main(String[] args) throws IOException {
        Painter painter= new Painter();
    }
}
